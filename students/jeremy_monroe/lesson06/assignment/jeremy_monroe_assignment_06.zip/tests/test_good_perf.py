"""
run linting only
"""
