"""
    Autograde Lesson 8 assignment

"""

import pytest

import inventory as l



def test_add_furniture(invoice_file, customer_name, item_code, item_description, item_monthly_price):



def single_customer(customer_name, invoice_file):


    