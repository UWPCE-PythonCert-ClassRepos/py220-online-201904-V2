# Graded as follows:
Reviewing the timings.csv file submitted, and ensure it complies with what follows:

Your program, called database.py, must output details of timing for all functions
in the program. Gather this data and write it to a file. The file should contain
function name, time taken, and number of records processed, and be called timing.csv.
