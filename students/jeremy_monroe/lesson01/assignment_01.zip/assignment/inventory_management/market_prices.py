""" Will eventually return the product market price. """

def get_latest_price(item_code):
    """ I'm just here to make things difficult. """

    # return 24
    return item_code
    # Raise an exception to force the user to Mock its output
