Grading
=======

For assignment 1, you will need to supply your own unit_tests.py 
and integration_test.py files.

The assignment is graded as follows:
1. Run the student unit_tests
2. Run coverage and linting using the regular batch file.
